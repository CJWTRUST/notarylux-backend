from flask import Blueprint, jsonify, request, session
from src.models.user import User, Job, JobTracker, db
from datetime import datetime, date

user_bp = Blueprint('user', __name__)

# Authentication routes
@user_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    
    # Check if user already exists
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already registered'}), 400
    
    user = User(
        email=data['email'],
        account_type=data['account_type'],
        first_name=data['first_name'],
        last_name=data['last_name'],
        phone=data.get('phone'),
        address=data.get('address'),
        city=data.get('city'),
        state=data.get('state', 'UT'),
        zip_code=data.get('zip_code'),
        notary_license=data.get('notary_license'),
        commission_expires=datetime.strptime(data['commission_expires'], '%Y-%m-%d').date() if data.get('commission_expires') else None
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'message': 'User registered successfully', 'user': user.to_dict()}), 201

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    
    if user and user.check_password(data['password']):
        session['user_id'] = user.id
        session['account_type'] = user.account_type
        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict()
        })
    
    return jsonify({'error': 'Invalid email or password'}), 401

@user_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

@user_bp.route('/current-user', methods=['GET'])
def get_current_user():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user = User.query.get(session['user_id'])
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify(user.to_dict())

# User management routes
@user_bp.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.json
    
    user.first_name = data.get('first_name', user.first_name)
    user.last_name = data.get('last_name', user.last_name)
    user.phone = data.get('phone', user.phone)
    user.address = data.get('address', user.address)
    user.city = data.get('city', user.city)
    user.state = data.get('state', user.state)
    user.zip_code = data.get('zip_code', user.zip_code)
    
    db.session.commit()
    return jsonify(user.to_dict())

# Job management routes
@user_bp.route('/jobs', methods=['POST'])
def create_job():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.json
    job = Job(
        client_id=session['user_id'],
        title=data['title'],
        description=data.get('description'),
        appointment_date=datetime.strptime(data['appointment_date'], '%Y-%m-%dT%H:%M') if data.get('appointment_date') else None,
        location=data.get('location'),
        document_count=data.get('document_count', 0),
        signer_count=data.get('signer_count', 1),
        witness_required=data.get('witness_required', False),
        fingerprinting_required=data.get('fingerprinting_required', False),
        ink_preference=data.get('ink_preference', 'blue'),
        special_instructions=data.get('special_instructions')
    )
    
    db.session.add(job)
    db.session.commit()
    
    # Create initial tracker items
    initial_milestones = [
        'Job Created',
        'Notary Assignment',
        'Notary En Route',
        'Notary Arrived',
        'Documents Signed',
        'Documents Shipped',
        'Job Completed'
    ]
    
    for milestone in initial_milestones:
        tracker_item = JobTracker(
            job_id=job.id,
            milestone=milestone,
            status='completed' if milestone == 'Job Created' else 'pending',
            timestamp=datetime.utcnow() if milestone == 'Job Created' else None
        )
        db.session.add(tracker_item)
    
    db.session.commit()
    
    return jsonify(job.to_dict()), 201

@user_bp.route('/jobs', methods=['GET'])
def get_jobs():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user_id']
    account_type = session['account_type']
    
    if account_type == 'client':
        jobs = Job.query.filter_by(client_id=user_id).all()
    elif account_type == 'notary':
        jobs = Job.query.filter_by(notary_id=user_id).all()
    elif account_type == 'admin':
        jobs = Job.query.all()
    else:
        jobs = []
    
    return jsonify([job.to_dict() for job in jobs])

@user_bp.route('/jobs/<int:job_id>', methods=['GET'])
def get_job(job_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    job = Job.query.get_or_404(job_id)
    return jsonify(job.to_dict())

@user_bp.route('/jobs/<int:job_id>/tracker', methods=['GET'])
def get_job_tracker(job_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    tracker_items = JobTracker.query.filter_by(job_id=job_id).order_by(JobTracker.created_at).all()
    return jsonify([item.to_dict() for item in tracker_items])

@user_bp.route('/jobs/<int:job_id>/tracker/<int:tracker_id>', methods=['PUT'])
def update_tracker_item(job_id, tracker_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    tracker_item = JobTracker.query.get_or_404(tracker_id)
    data = request.json
    
    tracker_item.status = data.get('status', tracker_item.status)
    tracker_item.notes = data.get('notes', tracker_item.notes)
    
    if data.get('status') == 'completed' and not tracker_item.timestamp:
        tracker_item.timestamp = datetime.utcnow()
    
    db.session.commit()
    return jsonify(tracker_item.to_dict())

@user_bp.route('/jobs/<int:job_id>/assign', methods=['PUT'])
def assign_notary(job_id):
    if 'user_id' not in session or session['account_type'] not in ['admin', 'notary']:
        return jsonify({'error': 'Not authorized'}), 403
    
    job = Job.query.get_or_404(job_id)
    data = request.json
    
    if session['account_type'] == 'notary':
        job.notary_id = session['user_id']
    else:
        job.notary_id = data.get('notary_id')
    
    job.status = 'assigned'
    
    # Update tracker
    tracker_item = JobTracker.query.filter_by(job_id=job_id, milestone='Notary Assignment').first()
    if tracker_item:
        tracker_item.status = 'completed'
        tracker_item.timestamp = datetime.utcnow()
    
    db.session.commit()
    return jsonify(job.to_dict())

# Dashboard data routes
@user_bp.route('/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user_id']
    account_type = session['account_type']
    
    if account_type == 'client':
        total_jobs = Job.query.filter_by(client_id=user_id).count()
        pending_jobs = Job.query.filter_by(client_id=user_id, status='pending').count()
        completed_jobs = Job.query.filter_by(client_id=user_id, status='completed').count()
    elif account_type == 'notary':
        total_jobs = Job.query.filter_by(notary_id=user_id).count()
        pending_jobs = Job.query.filter_by(notary_id=user_id, status='assigned').count()
        completed_jobs = Job.query.filter_by(notary_id=user_id, status='completed').count()
    elif account_type == 'admin':
        total_jobs = Job.query.count()
        pending_jobs = Job.query.filter_by(status='pending').count()
        completed_jobs = Job.query.filter_by(status='completed').count()
    else:
        total_jobs = pending_jobs = completed_jobs = 0
    
    return jsonify({
        'total_jobs': total_jobs,
        'pending_jobs': pending_jobs,
        'completed_jobs': completed_jobs,
        'in_progress_jobs': total_jobs - pending_jobs - completed_jobs
    })
