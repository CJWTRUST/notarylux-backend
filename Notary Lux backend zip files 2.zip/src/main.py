import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask
from flask_cors import CORS
from src.models.user import db, User, Job, JobTracker
from src.routes.user import user_bp
from datetime import datetime, date

app = Flask(__name__)
app.config["SECRET_KEY"] = 'notarylux-secret-key-2024-secure'

# Enable CORS for all routes
CORS(app, 
     supports_credentials=True,
     origins=['https://gregarious-kitsune-649a59.netlify.app', 'http://localhost:3000', 'http://localhost:5173'])

app.register_blueprint(user_bp, url_prefix='/api')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def create_sample_data():
    """Create sample users and data for testing"""
    
    # Check if admin user already exists
    admin_user = User.query.filter_by(email='CJWTrust@gmx.com').first()
    if admin_user:
        return  # Sample data already exists
    
    # Create Administrator account
    admin = User(
        email='CJWTrust@gmx.com',
        account_type='admin',
        first_name='Christopher',
        last_name='Johnson',
        phone='(801) 555-0100',
        address='123 Admin Street',
        city='Salt Lake City',
        state='UT',
        zip_code='84101'
    )
    admin.set_password('12345678!')
    db.session.add(admin)
    
    # Create sample Notary account
    notary = User(
        email='sarah.notary@example.com',
        account_type='notary',
        first_name='Sarah',
        last_name='Williams',
        phone='(801) 555-0200',
        address='456 Notary Lane',
        city='Provo',
        state='UT',
        zip_code='84604',
        notary_license='UT-12345',
        commission_expires=date(2025, 12, 31)
    )
    notary.set_password('notary123')
    db.session.add(notary)
    
    # Create sample Client account
    client = User(
        email='mike.client@example.com',
        account_type='client',
        first_name='Michael',
        last_name='Davis',
        phone='(801) 555-0300',
        address='789 Client Avenue',
        city='Ogden',
        state='UT',
        zip_code='84401'
    )
    client.set_password('client123')
    db.session.add(client)
    
    db.session.commit()
    
    # Create sample jobs
    job1 = Job(
        client_id=client.id,
        notary_id=notary.id,
        title='Real Estate Closing Documents',
        description='Notarization of home purchase documents',
        appointment_date=datetime(2024, 10, 15, 14, 0),
        location='789 Client Avenue, Ogden, UT 84401',
        status='assigned',
        document_count=15,
        signer_count=2,
        witness_required=True,
        fingerprinting_required=False,
        ink_preference='blue',
        special_instructions='Please bring extra pens and ensure all signatures are witnessed.'
    )
    db.session.add(job1)
    
    job2 = Job(
        client_id=client.id,
        title='Power of Attorney Documents',
        description='Notarization of financial power of attorney',
        appointment_date=datetime(2024, 10, 20, 10, 0),
        location='123 Business Center, Salt Lake City, UT 84101',
        status='pending',
        document_count=5,
        signer_count=1,
        witness_required=False,
        fingerprinting_required=True,
        ink_preference='black',
        special_instructions='Client prefers morning appointments.'
    )
    db.session.add(job2)
    
    db.session.commit()
    
    # Create tracker items for job1
    milestones = [
        ('Job Created', 'completed', datetime(2024, 10, 1, 9, 0)),
        ('Notary Assignment', 'completed', datetime(2024, 10, 1, 10, 30)),
        ('Notary En Route', 'pending', None),
        ('Notary Arrived', 'pending', None),
        ('Documents Signed', 'pending', None),
        ('Documents Shipped', 'pending', None),
        ('Job Completed', 'pending', None)
    ]
    
    for milestone, status, timestamp in milestones:
        tracker_item = JobTracker(
            job_id=job1.id,
            milestone=milestone,
            status=status,
            timestamp=timestamp,
            notes=f'Sample note for {milestone}' if status == 'completed' else None
        )
        db.session.add(tracker_item)
    
    # Create tracker items for job2
    for milestone, _, _ in milestones:
        tracker_item = JobTracker(
            job_id=job2.id,
            milestone=milestone,
            status='completed' if milestone == 'Job Created' else 'pending',
            timestamp=datetime(2024, 10, 2, 11, 0) if milestone == 'Job Created' else None
        )
        db.session.add(tracker_item)
    
    db.session.commit()

def init_database():
    """Initialize database with tables and sample data"""
    db.create_all()
    create_sample_data()

# Only initialize database if running directly or in development
if __name__ == '__main__' or app.config.get('ENV') == 'development':
    with app.app_context():
        init_database()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
