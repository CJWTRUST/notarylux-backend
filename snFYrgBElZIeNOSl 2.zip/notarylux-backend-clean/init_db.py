#!/usr/bin/env python3
"""
Database initialization script for NotaryLux platform
"""
import os
import sys

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.main import app, db
from src.main import create_sample_data

def init_database():
    """Initialize the database with tables and sample data"""
    with app.app_context():
        print("Creating database tables...")
        db.create_all()
        print("Database tables created successfully!")
        
        print("Creating sample data...")
        create_sample_data()
        print("Sample data created successfully!")
        
        print("Database initialization complete!")

if __name__ == '__main__':
    init_database()
