from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    account_type = db.Column(db.String(20), nullable=False)  # 'client', 'notary', 'admin'
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    address = db.Column(db.String(200), nullable=True)
    city = db.Column(db.String(50), nullable=True)
    state = db.Column(db.String(2), nullable=True)
    zip_code = db.Column(db.String(10), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Notary-specific fields
    notary_license = db.Column(db.String(50), nullable=True)
    commission_expires = db.Column(db.Date, nullable=True)
    
    # Relationships
    jobs_as_client = db.relationship('Job', foreign_keys='Job.client_id', backref='client', lazy='dynamic')
    jobs_as_notary = db.relationship('Job', foreign_keys='Job.notary_id', backref='notary', lazy='dynamic')

    def __repr__(self):
        return f'<User {self.email}>'

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'account_type': self.account_type,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone': self.phone,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'zip_code': self.zip_code,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active,
            'notary_license': self.notary_license,
            'commission_expires': self.commission_expires.isoformat() if self.commission_expires else None
        }

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    notary_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    appointment_date = db.Column(db.DateTime, nullable=True)
    location = db.Column(db.String(300), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, assigned, in_progress, completed, cancelled
    document_count = db.Column(db.Integer, default=0)
    signer_count = db.Column(db.Integer, default=1)
    witness_required = db.Column(db.Boolean, default=False)
    fingerprinting_required = db.Column(db.Boolean, default=False)
    ink_preference = db.Column(db.String(10), default='blue')  # blue, black
    special_instructions = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Tracking fields
    notary_en_route = db.Column(db.Boolean, default=False)
    notary_arrived = db.Column(db.Boolean, default=False)
    documents_signed = db.Column(db.Boolean, default=False)
    documents_shipped = db.Column(db.Boolean, default=False)
    tracking_number = db.Column(db.String(50), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'client_id': self.client_id,
            'notary_id': self.notary_id,
            'title': self.title,
            'description': self.description,
            'appointment_date': self.appointment_date.isoformat() if self.appointment_date else None,
            'location': self.location,
            'status': self.status,
            'document_count': self.document_count,
            'signer_count': self.signer_count,
            'witness_required': self.witness_required,
            'fingerprinting_required': self.fingerprinting_required,
            'ink_preference': self.ink_preference,
            'special_instructions': self.special_instructions,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'notary_en_route': self.notary_en_route,
            'notary_arrived': self.notary_arrived,
            'documents_signed': self.documents_signed,
            'documents_shipped': self.documents_shipped,
            'tracking_number': self.tracking_number
        }

class JobTracker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    milestone = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed
    timestamp = db.Column(db.DateTime, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    job = db.relationship('Job', backref='tracker_items')

    def to_dict(self):
        return {
            'id': self.id,
            'job_id': self.job_id,
            'milestone': self.milestone,
            'status': self.status,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
