# NotaryLux Backend API

This is the Flask backend API for the NotaryLux mobile notary platform.

## Features

- User authentication and management
- Job tracking and management
- Real-time job status updates
- CRM functionality
- SQLite database (production ready for PostgreSQL)

## Deployment

This backend is configured for deployment on Render.com with the following files:

- `Procfile`: Web server configuration
- `requirements.txt`: Python dependencies
- `render.yaml`: Render deployment configuration
- `runtime.txt`: Python version specification

## API Endpoints

All API endpoints are prefixed with `/api`:

- `/api/register` - User registration
- `/api/login` - User authentication
- `/api/jobs` - Job management
- `/api/tracker` - Job tracking updates

## Frontend

The frontend is deployed separately on Netlify at:
https://gregarious-kitsune-649a59.netlify.app

## CORS Configuration

The backend is configured to accept requests from:
- https://gregarious-kitsune-649a59.netlify.app (production frontend)
- http://localhost:3000 (development)
- http://localhost:5173 (Vite development server)
