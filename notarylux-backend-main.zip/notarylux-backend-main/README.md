# notarylux-backend
Flask backend API for NotaryLux mobile notary platform
